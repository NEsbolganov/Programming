package org.example.app.services;

import org.example.web.dto.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.NotEmpty;
import java.util.List;

@Service
public class BookService {

    private final ProjectRepository<Book> bookRepo;

    @Autowired
    public BookService(ProjectRepository<Book> bookRepo) {
        this.bookRepo = bookRepo;
    }

    public List<Book> getAllBooks() {
        return bookRepo.retreiveAll();
    }

    public void saveBook(Book book) {
        if(book.getAuthor().isEmpty()==false || book.getTitle().isEmpty()==false){
            bookRepo.store(book);
        }
    }

    public boolean removeBookById(Integer bookIdToRemove) {
        return bookRepo.removeItemById(Integer.valueOf(Integer.valueOf(bookIdToRemove)));
    }

//    @AssertTrue
    public boolean removeBookByAuthor(String bookAuthorNameToRemove) {
        return bookRepo.removeItemByAuthor(bookAuthorNameToRemove);
    }

    public boolean removeBookByTitle(String bookTitleNameToRemove) {
        return bookRepo.removeItemByTitle(bookTitleNameToRemove);
    }

    public boolean removeBookBySize(Integer bookSizeToRemove) {
        return bookRepo.removeItemBySize(bookSizeToRemove);
    }
}
