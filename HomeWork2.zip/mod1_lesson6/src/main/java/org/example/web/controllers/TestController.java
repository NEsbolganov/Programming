package org.example.web.controllers;

import org.springframework.format.datetime.joda.LocalDateTimeParser;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.apache.log4j.Logger;

@Controller
public class TestController {
    private Logger logger = Logger.getLogger(TestController.class);

    public String Hello="Hello World";
    @GetMapping("/test")
    public String test(Model model){
        logger.info("/test is being checked");
        model.addAttribute("hello",Hello);
        return "test";
    }
}
