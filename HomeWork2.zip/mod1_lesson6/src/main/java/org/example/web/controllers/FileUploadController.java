package org.example.web.controllers;

import org.apache.log4j.Logger;
import org.example.app.exceptions.BookShelfLoginException;
import org.example.app.exceptions.FileUploadException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;

@Controller
@RequestMapping(value = "/books")
public class FileUploadController {
    private Logger logger = Logger.getLogger(FileUploadController.class);

    @PostMapping("/uploadFile")
    public String uploadFile(@RequestParam("file") MultipartFile file) throws FileUploadException, IOException {
        String name = file.getOriginalFilename();
        byte[] bytes=file.getBytes();

        FileNotFoundException exception;
        //create dir
        String rootPath = System.getProperty("catalina.home");
        if(file.isEmpty())throw new FileUploadException("You need to upload some files");
        File dir = new File(rootPath+File.separator+"external_uploads");
        if(!dir.exists()){
            dir.mkdirs();
        }

        //creation of file
        File serverFile = new File(dir.getAbsolutePath()+File.separator+name);
        BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
        stream.write(bytes);
        stream.close();

        logger.info("new  file saved at: "+serverFile.getAbsolutePath());
        return "redirect:/books/shelf";
    }


    @ExceptionHandler(FileUploadException.class)
    public String hadleError(Model model, FileUploadException exception){
        model.addAttribute("errorMessage",exception.getMessage());
        return "errors/500";
    }
}
